var level1 = {}
  , levelParser = require('../../lib/level-parser')
  , levelData = require('../levels/level-1.json')

level1.create = function() {
  levelParser.parse(this.game, levelData)
}

level1.update = function() {
  levelParser.checkGroupCollisions()
}

module.exports = level1
