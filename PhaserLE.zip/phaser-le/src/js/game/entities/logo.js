var Phaser = require('Phaser')

var Logo = function(game, x, y) {
  Phaser.Sprite.call(this, game, x, y, '/images/static/phaser-le-logo.png')
}

Logo.prototype = Phaser.Sprite.prototype
Logo.prototype.constructor = Logo

module.exports = Logo
