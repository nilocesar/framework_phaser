var Phaser = require('Phaser')
  , _ = require('lodash')
  , states =
    { boot: require('./states/boot.js')
    , preloader: require('./states/preloader.js')
    , level1: require('./states/level1')
    , level2: require('./states/level2')
    , level3: require('./states/level3')
    }

  var w = window.innerWidth
    , h = window.innerHeight
    , game = new Phaser.Game((h > w) ? h : w, (h > w) ? w : h, Phaser.AUTO, 'game')

// Automatically register each state.
_.each(states, function(state, key) {
  game.state.add(key, state)
})

game.state.start('boot')
