var parallaxManager = {}
  , fg = null
  , mg = null
  , bg = null

parallaxManager.showLayers = function(game) {
  bg = game.add.tileSprite(0, 0, game.world.width, game.height, '/images/static/background.png')
  mg = game.add.tileSprite(0, 0, game.world.width, game.height, '/images/static/midground.png')
  fg = game.add.tileSprite(0, game.height, game.world.width, game.cache.getImage('/images/static/foreground.png').height, '/images/static/foreground.png')
  fg.anchor.setTo(0, 1)

  bg.fixedToCamera = true
  mg.fixedToCamera = true
  fg.fixedToCamera = true

  game.world.sendToBack(mg)
  game.world.sendToBack(bg)
}

parallaxManager.moveToCamera = function(game) {
  bg.tilePosition.x = game.camera.position.x * -0.2
  mg.tilePosition.x = game.camera.position.x * -0.4
  fg.tilePosition.x = game.camera.position.x * -1.3
  fg.cameraOffset.y = Math.round(game.height + fg.height - (game.camera.position.y / game.world.height) * fg.height)
}

module.exports = parallaxManager
