module.exports = function setupParticles(game) {

  var emitter = game.add.emitter(game.world.centerX, -32, 600)

  emitter.makeParticles('/images/static/static-images', ['1.png', '2.png', '3.png', '4.png', '5.png', '6.png'])
  emitter.maxParticleScale = 1
  emitter.minParticleScale = 0.5
  emitter.setYSpeed(60, 100)
  emitter.gravity = 0
  emitter.width = game.world.width * 1.1
  emitter.minRotation = -70
  emitter.maxRotation = 70

  // Launch an initial wave of particles onto the scene.
  emitter.height = game.world.height * 2
  emitter.explode(20000, 100)
  emitter.height = 0

  emitter.start(false, 20000, 500)
}
