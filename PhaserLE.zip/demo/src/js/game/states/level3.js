var LevelData = require('../levels/level3')
  , levelParser = require('../../lib/level-parser')
  , leafParticles = require('../util/leaf-particles')
  , parallaxManager = require('../util/parallax-manager')
  , level3 = {}

level3.create = function() {
  levelParser.parse(this.game, LevelData)

  parallaxManager.showLayers(this.game)

  leafParticles(this.game)
}

level3.update = function() {
  levelParser.checkGroupCollisions()
  parallaxManager.moveToCamera(this.game)
}

level3.render = function() {
  levelParser.renderDebugBodies()
}

module.exports = level3
