var LevelParser = require('../../lib/level-parser')
  , Preloader = {}

Preloader.preload = function () {
  LevelParser.loadAssets(this.game)
}

Preloader.create = function () {
  this.game.state.start('level1')
}

module.exports = Preloader
