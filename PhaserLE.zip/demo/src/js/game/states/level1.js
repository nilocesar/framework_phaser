var LevelData = require('../levels/level1')
  , levelParser = require('../../lib/level-parser')
  , leafParticles = require('../util/leaf-particles')
  , parallaxManager = require('../util/parallax-manager')
  , level1 = {}

level1.create = function() {
  levelParser.parse(this.game, LevelData)

  parallaxManager.showLayers(this.game)

  leafParticles(this.game)
}

level1.update = function() {
  levelParser.checkGroupCollisions()
  parallaxManager.moveToCamera(this.game)
}

level1.render = function() {
  levelParser.renderDebugBodies()
}

module.exports = level1
