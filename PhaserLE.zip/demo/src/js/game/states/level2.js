var LevelData = require('../levels/level2')
  , levelParser = require('../../lib/level-parser')
  , leafParticles = require('../util/leaf-particles')
  , parallaxManager = require('../util/parallax-manager')
  , level2 = {}

level2.create = function() {
  levelParser.parse(this.game, LevelData)

  parallaxManager.showLayers(this.game)

  leafParticles(this.game)
}

level2.update = function() {
  levelParser.checkGroupCollisions()
  parallaxManager.moveToCamera(this.game)
}

level2.render = function() {
  levelParser.renderDebugBodies()
}

module.exports = level2
