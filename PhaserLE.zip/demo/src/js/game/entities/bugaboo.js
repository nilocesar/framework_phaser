var Phaser = require('Phaser')

  , walkSpeed = 50

//  Here is a custom game object

var Bugaboo = function (game, x, y, gameClass) {
  Phaser.Sprite.call(this, game, x, y, '/images/default-atlas', gameClass)

  this.game.physics.arcade.enable(this)
  this.body.gravity.y = 400

  this.anchor.setTo(.5, .5)
  this.body.setSize(75, 52, 15, 45)

  this.animations.add('idle', Phaser.Animation.generateFrameNames('bugaboo_walk', 1, 11, '.png', 1), 15, true)
  this.animations.add('death', Phaser.Animation.generateFrameNames('bugaboo_death', 1, 10, '.png', 1), 15)
  this.animations.play('idle')

  var death = this.animations.getAnimation('death')

  death.onComplete.add(function() {
    this.kill()
  }, this)
}

Bugaboo.prototype = Object.create(Phaser.Sprite.prototype)
Bugaboo.prototype.constructor = Bugaboo

Bugaboo.prototype.init = function (isInEditor) {
  if(!isInEditor) {
    this.changeDirection()
  }
}

Bugaboo.prototype.dying = false

Bugaboo.prototype.changeDirection = function() {
  this.scale.x *= -1
  this.body.velocity.x = this.scale.x > 0 ? walkSpeed * -1 : walkSpeed
}

Bugaboo.prototype.update = function() {

  if (this.body.touching.left || this.body.touching.right) {
    this.changeDirection()
  }
}

Bugaboo.prototype.die = function() {
  this.animations.play('death')
  this.body.velocity.x = 0
  this.dying = true
}

module.exports = Bugaboo
