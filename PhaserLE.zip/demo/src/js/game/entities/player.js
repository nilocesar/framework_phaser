var Phaser = require('Phaser')
  , cursors

  , canDoubleJump = true
  , canDash = true
  , dashing = false
  , jumping = true
  , dying = false

  , coinsCollected = 0
  , runSpeed = 350
  , dashSpeed = 1000
  , currentSpeed = 0
  , takingDamage = false
  , enteringPortal = false

  , originalPosition = { x: 0, y: 0 }
  , hasHitEnemy = false

var Player = function (game, x, y) {

  Phaser.Sprite.call(this, game, x, y, '/images/default-atlas')

  this.animations.add('walk', Phaser.Animation.generateFrameNames('run', 0, 5, '.png', 1), 10, true)
  this.animations.add('idle', Phaser.Animation.generateFrameNames('idle', 0, 3, '.png', 1), 10, true)
  this.animations.add('jump', Phaser.Animation.generateFrameNames('jump', 0, 3, '.png', 1), 10, true)
  this.animations.add('dash', Phaser.Animation.generateFrameNames('dash', 0, 3, '.png', 1), 10, false)
  this.animations.add('damage', Phaser.Animation.generateFrameNames('damage', 0, 3, '.png', 1), 10, false)
  this.animations.add('death', Phaser.Animation.generateFrameNames('death', 0, 12, '.png', 1), 10, false)

  this.animations.play('idle')
  dashing = false

  var dash = this.animations.getAnimation('dash')
    , death = this.animations.getAnimation('death')

  dash.onComplete.add(function() {
    this.stopDashing()
  }, this)

  death.onComplete.add(function() {
    this.resetPosition()
    dying = false
  }, this)

  enteringPortal = false
  dying = false

  var damage = this.animations.getAnimation('damage')

  damage.onComplete.add(function() {
    this.animations.play('idle')
    takingDamage = false
  }, this)


  this.anchor.setTo(.59, .5)

  this.game.physics.arcade.enable(this)
  this.body.setSize(70, 120, 45, 20)
  this.body.offset.x -= 35

  this.body.drag.x = 1000

  originalPosition.x = x
  originalPosition.y = y
}

Player.prototype = Object.create(Phaser.Sprite.prototype)
Player.prototype.constructor = Player

Player.prototype.init = function (isInEditor) {
  this.le = isInEditor

  if (!this.le) {
    cursors = this.game.input.keyboard.createCursorKeys()
    cursors.up.onDown.add(jump, this)

    this.body.gravity.y = 1200
    this.game.camera.follow(this, Phaser.Camera.FOLLOW_PLATFORMER)
  }
}

Player.prototype.update = function() {

  if (enteringPortal || dying) {
    return
  }

  checkDash.call(this)

  this.checkInput()

  checkDirection(this.scale, this.body)

  if (dashing || takingDamage) {
    return
  }

  this.checkLanded()

  hasHitEnemy = false

  if (this.y > this.game.world.height) {
    this.resetPosition()
  }
}


Player.prototype.checkLanded = function() {
  if (this.body.touching.down && !hasHitEnemy) {

    canDoubleJump = true
    jumping = false

    if (Math.abs(this.body.velocity.x) < 40) {
      this.body.velocity.x = 0
      this.animations.play('idle')
    } else {
      this.animations.play('walk')
    }
  } else {
    this.animations.play('jump')
  }
}

Player.prototype.resetPosition = function () {
  this.x = originalPosition.x
  this.y = originalPosition.y
  this.body.velocity.setTo(0, 0)
  this.animations.play('jump')
}

Player.prototype.hitPortal = function(portal) {

  var game = this.game
    , portalCenterX = portal.x + (portal.width / 2) + 55
    , portalCenterY = portal.y + (portal.height / 2)
    , duration = 1500
    , scaleTweenData =
      { x: [0.5, 1, 0.5, 1, 0]
      , y: [1, 0.5, 1, 0.5, 0]
      }
    , scaleTween = this.game.add.tween(this.scale).to(scaleTweenData, duration).interpolation(function(v, k) {
        return Phaser.Math.bezierInterpolation(v, k)
      }).start()

  scaleTween.onComplete.add(function() {
    game.state.start(portal.levelEditorProperties.nextState)
  })

  this.animations.play('jump')
  enteringPortal = true

  this.body.enable = false
  this.body.enable = false

  this.game.add.tween(this).to({ x: portalCenterX, y:portalCenterY }, duration).start()
}

Player.prototype.checkInput = function() {

  if (takingDamage) {
    return
  }

  currentSpeed = dashing ? dashSpeed : runSpeed

  if (cursors.right.isDown) {
    this.body.velocity.x = currentSpeed
  } else if (cursors.left.isDown) {
    this.body.velocity.x = currentSpeed * -1
  }
}

function checkDirection(scale, body) {
  if (body.velocity.x < -10) {
    scale.x = -1
  } else if (body.velocity.x > 10) {
    scale.x = 1
  }
}

Player.prototype.die = function() {

  // The second condition prevents the death animation playing twice.
  if (dying || this.x === originalPosition.x) {
    return
  }

  dying = true
  jumping = false
  dashing = false
  this.animations.play('death')
  this.body.velocity.setTo(0)
}

Player.prototype.hitWall = function() {

}

Player.prototype.hitEnemy = function(enemy) {

  if (takingDamage || enemy.dying)  {
    return
  }

  if (dashing || jumping) {

    jump.call(this, true)
    enemy.die()
    canDash = true
    hasHitEnemy = true
  } else {
    this.takeDamage()
  }
}

Player.prototype.collectCoin = function(coin) {
  coinsCollected += coin.value
  coin.collect()
}

Player.prototype.takeDamage = function() {
  takingDamage = true
  this.animations.play('damage')
}

function jump(bigJump) {

  if (takingDamage) {
    return
  }

  jumping = true

  // Jumping while dashing will cancel the dash.
  if (dashing) {
    this.stopDashing()
  }

  // This boolean check is explicit as sometimes it's passed a Key object.
  if (bigJump === true || this.body.touching.down) {
    this.body.velocity.y = -580
    this.animations.play('jump')
  } else if (canDoubleJump) {
    this.body.velocity.y = -400
    canDoubleJump = false
    this.animations.play('jump')
  }
}

function checkDash() {

  // Only enable dashing and apply friction when touching the floor.
  if (this.body.touching.down) {
    canDash = true
    this.body.drag.x = 1000
  } else {
    this.body.drag.x = 0
  }

  if (canDash && !dashing && this.game.input.keyboard.isDown(Phaser.Keyboard.Z)) {
    this.animations.play('dash')
    dashing = true
    canDash = false

    this.body.velocity.x = this.getDashSpeed()
  }
}

Player.prototype.getDashSpeed = function() {
  return this.scale.x > 0 ? dashSpeed : dashSpeed * -1
}

Player.prototype.getRunSpeed = function() {
  return this.scale.x > 0 ? runSpeed : runSpeed * -1
}

Player.prototype.stopDashing = function() {
  if (this.body.velocity.x) {
    this.body.velocity.x = this.getRunSpeed()
  }

  dashing = false
}

module.exports = Player
