var Phaser = require('Phaser')

var Portal = function (game, x, y) {

  Phaser.Sprite.call(this, game, x, y, '/images/default-atlas')
  this.animations.add('idle', Phaser.Animation.generateFrameNames('portal', 0, 3, '.png', 1), 10, true)
  this.animations.play('idle')

  this.game.physics.arcade.enable(this)
  this.body.immovable = true
  this.nextState = null
}

Portal.prototype = Object.create(Phaser.Sprite.prototype)
Portal.prototype.constructor = Portal

module.exports = Portal
