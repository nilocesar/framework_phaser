var Phaser = require('Phaser')

//  Here is a custom game object
var Buzzpuck = function (game, x, y, gameClass) {
  Phaser.Sprite.call(this, game, x, y, '/images/default-atlas', gameClass)

  this.game.physics.arcade.enable(this)

  this.animations.add('idle', Phaser.Animation.generateFrameNames('buzzpuck_fly', 1, 3, '.png', 1), 15, true)
  this.animations.add('death', Phaser.Animation.generateFrameNames('buzzpuck_death', 1, 13, '.png', 1), 15)
  this.animations.play('idle')

  this.anchor.setTo(.5, .5)
  this.body.setSize(50, 50, 40, 50)

  var death = this.animations.getAnimation('death')

  death.onComplete.add(function() {
    this.visible = false

    var timer = game.time.create()
    timer.add(3000, this.respawn, this)
    timer.start()

  }, this)
}

Buzzpuck.prototype = Object.create(Phaser.Sprite.prototype)
Buzzpuck.prototype.constructor = Buzzpuck

Buzzpuck.prototype.dying = false

Buzzpuck.prototype.respawn = function() {
  this.visible = true
  this.play('idle')
  this.dying = false
}

Buzzpuck.prototype.die = function() {
  this.animations.play('death')
  this.body.velocity.x = 0
  this.dying = true
}

module.exports = Buzzpuck
