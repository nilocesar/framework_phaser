var Phaser = require('Phaser')

var Spikes2 = function (game, x, y) {

  Phaser.Sprite.call(this, game, x, y, '/images/default-atlas')
  this.animations.add('idle', ['tile_spike02.png'], 8, true)
  this.animations.play('idle')

  this.game.physics.arcade.enable(this)
  this.body.immovable = true

  this.body.setSize(this.width, 80, 0, 10)
}

Spikes2.prototype = Object.create(Phaser.Sprite.prototype)
Spikes2.prototype.constructor = Spikes2

module.exports = Spikes2
