var Phaser = require('Phaser')

var Coin = function (game, x, y) {

  Phaser.Sprite.call(this, game, x, y, '/images/default-atlas')
  this.animations.add('idle', Phaser.Animation.generateFrameNames('orbIdle', 0, 3, '.png', 1), 8, true)
  this.animations.add('collect', Phaser.Animation.generateFrameNames('orbpop', 0, 8, '.png', 1), 8)
  this.animations.play('idle')

  this.value = 10

  this.animations.getAnimation('collect').onComplete.add(this.kill)

  this.game.physics.arcade.enable(this)
  this.body.immovable = true
  this.body.setSize(this.width/2, this.height/2, this.width/4, this.height/4)
}

Coin.prototype = Object.create(Phaser.Sprite.prototype)
Coin.prototype.constructor = Coin

Coin.prototype.collect = function() {
  if(this.animations.currentAnim.name === 'idle') {
    this.animations.play('collect')
  }
  this.kill()
}

module.exports = Coin
