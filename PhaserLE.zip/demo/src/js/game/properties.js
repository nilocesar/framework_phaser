var npmProperties = require('../../../package.json')

module.exports =
  { title: 'PhaserLE Project'
  , description: npmProperties.description
  , userHash: '501f769facb1293c7a544dc12e6555c8:'
  , serverURL: 'http://localhost'
  , port: 3020
  , liveReloadPort: 3021
  , analyticsId: 'UA-53585230-1'

  , cdnAddress: ''

  // Debug settings.
  , showStats: true
  , mute: false
  , debugCollisions: false
  }
