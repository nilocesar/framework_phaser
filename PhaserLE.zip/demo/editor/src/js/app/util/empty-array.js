module.exports = function(array) {
  while (array.length > 0) {
    array.pop()
  }
}
